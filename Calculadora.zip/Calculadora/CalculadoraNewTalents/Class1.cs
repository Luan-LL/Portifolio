﻿using System;

namespace CalculadoraNewTalents
{
    public class Class1
    {

    }
}
