using CalculadoraNewTalents;

namespace CalculadoraTestes
{
        public class TesteCaculadora
        {
            public Calculadora construirClasse()
            {
                string data = "20/05/2024";
                Calculadora calc = new Calculadora("20/05/2024");
                return calc;
            }
            [Theory]
            [InlineData(1, 2, 3)]
            [InlineData(10, 2, 12)]
            public void TesteSomar(int val1, int val2, int resultado)
            {
                Calculadora calc = construirClasse();

                int resultadoCalculadora = calc.somar(val1, val2);

                Assert.Equal(resultado, resultadoCalculadora);
            }
            [Theory]
            [InlineData(2, 4, -2)]
            [InlineData(10, 5, 5)]
            public void TesteSubtrair(int val1, int val2, int resultado)
            {
                Calculadora calc = construirClasse();
                int resultadoCalculadora = calc.subtrair(val1, val2);

                Assert.Equal(resultado, resultadoCalculadora);
            }
            [Theory]
            [InlineData(4, 5, 20)]
            [InlineData(2, 2, 4)]
            public void TesteMultiplicar(int val1, int val2, int resultado)
            {
                Calculadora calc = construirClasse();
                int resultadoCalculadora = calc.multiplicar(val1, val2);

                Assert.Equal(resultado, resultadoCalculadora);
            }
            [Theory]
            [InlineData(12, 2, 6)]
            [InlineData(4, 1, 4)]
            public void TesteDividir(int val1, int val2, int resultado)
            {
                Calculadora calc = construirClasse();
                int resultadoCalculadora = calc.dividir(val1, val2);

                Assert.Equal(resultado, resultadoCalculadora);
            }
            [Fact]
            public void TesteDivis�oPorZero()
            {
                Calculadora calc = construirClasse();
                Assert.Throws<DivideByZeroException>(() => calc.dividir(3, 0));
            }
            [Fact]
            public void TestarHistorico()
            {
                Calculadora calc = construirClasse();

                calc.somar(1, 2);
                calc.somar(5, 4);
                calc.somar(3, 5);
                calc.somar(7, 6);

                var lista = calc.historico();

                Assert.NotEmpty(lista);
                Assert.Equal(3, lista.Count);

            }
        }
    }